import { v2 as cloudinary } from "cloudinary";

cloudinary.config({
  cloud_name: "dttazo51h",
  api_key: "987951652968343",
  api_secret: "yiTX5s--nQlVPeeJv4gwtPUJY5k",
});

export { cloudinary };
